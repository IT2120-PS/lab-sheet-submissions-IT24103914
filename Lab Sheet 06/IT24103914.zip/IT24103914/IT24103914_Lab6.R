getwd()
setwd("D:\\Users\\nethmi\\OneDrive\\Desktop\\IT24103914")

#Q1 
#Part 1
#Binomial Distribution
#Here, random variable X has binomial distribution with n=50 and p=0.85

#Part 2
1 - pbinom(47, 50, 0.85,lower.tail = TRUE)

#Q2 
#Part 1
#Number of calls receivered in call center per one hour

#Part 2
#Here, random variable X has poisson distribution with lambda=12

#Part 3
dpois(15,12)