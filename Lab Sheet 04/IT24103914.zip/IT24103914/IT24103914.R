setwd("C:\\Users\\IT24103914\\Desktop\\IT24103914")

branchdata <- read.table("Exercise.txt", header = TRUE, sep = ",")
head(branchdata)

#Q3
boxplot(branchdata$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue",
        border = "darkblue")

grid()

#Q4
summary(branchdata$Advertising_X2)
IQR(branchdata$Advertising_X2)

#Q5
get_outliers <- function(z) {
  q1 <- quantile(z, 0.25)
  q3 <- quantile(z, 0.75)
  
  iqr <- q3 - q1
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  outliers <- z[z < lb | z > ub]
  print(outliers)
  
}

outliers <- get_outliers(branchdata$Years_X3)
print(outliers)